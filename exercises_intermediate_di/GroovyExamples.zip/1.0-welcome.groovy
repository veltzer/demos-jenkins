print 'Welcome to Groovy'
