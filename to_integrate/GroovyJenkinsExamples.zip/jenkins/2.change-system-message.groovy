//import jenkins.model.*;

//Jenkins.instance.setSystemMessage('Welcome to Intermediate Jenkins')
Jenkins.instance.systemMessage = 'Welcome to Salesforce - Intermediate Jenkins'
Jenkins.instance.save()
