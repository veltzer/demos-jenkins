int i = 1
println 'increment i until reaches 10'
do {
    println(i)
    i++
} while(i <= 10)

println 'decrease i until reaches 0'
while (i > 0) {
  i--
  println i
}
