// a standalone single line comment
println 'Hello World!!!' // a comment till the end of the line

/* a standalone multiline comment
   spanning two lines */
println 'Welcome to Kavin School' /* a multiline comment starting
                   at the end of a statement */
println 100 /* hundread */ + 200 /* plud two hundread */

