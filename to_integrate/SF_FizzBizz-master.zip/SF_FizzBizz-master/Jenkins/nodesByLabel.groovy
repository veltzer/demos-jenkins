pipeline {
    agent any

    stages {
        stage('Nodes By Label') {
            steps {
                nodesByLabel('master')
                nodesByLabel('unix')
                nodesByLabel('win')
                nodesByLabel('mac')
                nodesByLabel('not-existing-node')
            }
        }
    }
}