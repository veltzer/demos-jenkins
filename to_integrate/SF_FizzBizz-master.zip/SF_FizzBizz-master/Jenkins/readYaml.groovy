pipeline {
    agent {
        label "unix"
    }

    stages {
        stage('Read Random Yml Information') {
            steps {
                echo 'checkout code'
                git 'https://github.com/kpassoubady/SF_FizzBizz.git'
                echo 'Current Yaml contents'
                sh 'cat ./src/test/resources/randomInfo.yml'
                readRandomInformation()
            }
        }
    }
}

private void readRandomInformation() {
    datas = readYaml file: './src/test/resources/randomInfo.yml'
    doe = datas.doe
    frenchHens = datas.frenchHens
    turtleDoves = datas.turtleDoves
    println "datas--> " + datas
    println "doe: $doe"
    print "frenchHens: ${frenchHens}"
    print "turtleDoves: ${turtleDoves}"
    println datas.applications.service2.serviceNamespace
}