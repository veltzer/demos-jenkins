println 'when i reaches 5 come out of the loop'
for (int i = 1; i <= 10; i++) {
    if (i == 5) {
        break
    }
    println(i)
}
