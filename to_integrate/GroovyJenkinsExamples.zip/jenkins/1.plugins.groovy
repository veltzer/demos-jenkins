println(Jenkins.instance.pluginManager.plugins)
